/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Cookie.CookieUtils;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kinhc
 */
@WebServlet(urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        String username = CookieUtils.get("username", req);
        String password = CookieUtils.get("password", req);
        req.setAttribute("username", username);
        req.setAttribute("password", password);
        req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String remember = req.getParameter("remember");
        // kiểm tra tài khoản đăng nhập
        if (!username.equalsIgnoreCase("poly")) {
            req.setAttribute("message", "Sai tên đăng nhập!");
        } else if (password.length() < 6) {
            req.setAttribute("message", "Sai mật khẩu!");
        } else {
            req.setAttribute("message", "Đăng nhập thành công!");
            int hours = (remember == null) ? 0 : 30*24;
            CookieUtils.add("username", username, hours, resp);
            CookieUtils.add("password", password, hours, resp);
           
        }
        req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
    }
}
