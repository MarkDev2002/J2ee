/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import Models.Staff;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DateTimeConverter;

@MultipartConfig
@WebServlet("/StaffForm")
public class StaffServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/StaffForm/form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            File dir = new File(req.getServletContext().getRealPath("/files"));
            if (!dir.exists()) {
                dir.mkdirs();
            }

            Part photo = req.getPart("photo_file");
            File photoFile = new File(dir, photo.getSubmittedFileName());
            photo.write(photoFile.getAbsolutePath());
            // Định dạng thời gian nhập vào
            DateTimeConverter dtc = new DateConverter(new Date());
            dtc.setPattern("MM/dd/yyyy");
            ConvertUtils.register(dtc, Date.class);
            Staff staff = new Staff();

            // Đọc tham số vào các thuộc tính của bean staff
            BeanUtils.populate(staff, req.getParameterMap());
            staff.setPhoto(photoFile.getName());
            // Chia sẻ với result.jsp
            req.setAttribute("bean", staff);
        } catch (Exception e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("/views/StaffForm/result.jsp").forward(req, resp);
    }
}
