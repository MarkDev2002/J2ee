$(document).ready(function(){
	setInterval(function(){
		document.getElementById('alert').style.display = "none";
			}, 3000);
})