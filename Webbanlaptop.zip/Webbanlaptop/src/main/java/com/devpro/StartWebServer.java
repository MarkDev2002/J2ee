package com.devpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartWebServer {
	public static void main(String[] args) {
		SpringApplication.run(StartWebServer.class, args);
	}
}