package model;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Products {

    public Products() {

    }

    public List<Product> showProduct(String tensp) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/QLDienThoaiAssign2";
            Connection con = DriverManager.getConnection(url, "root", "");
            String sql = "select * from Products";
            if (tensp.length() > 0) {
                sql += " where Name like '" + tensp + "&'";
            }
            Statement stm = (Statement) con.createStatement();
            ResultSet rs = ((java.sql.Statement) stm).executeQuery(sql);
            List<Product> list;
            list = new ArrayList<>();
            while (rs.next()) {
                String code = rs.getString("Code");
                String name = rs.getString("Name");
                float price = rs.getFloat("Price");
                Product sp = new Product(code, name, price);
                list.add(sp);
            }
        } catch (ClassNotFoundException | SQLException e) {
            // TODO: handle exception

        }
        return null;
    }
}
