package model;

public class Product {

    private String code1;
    private String name;
    private float price;

    public Product(String code, String name, float price) {
        this.code1 = code;
        this.name = name;
        this.price = price;
    }

    public Product() {

    }

    public String getCode() {
        return code1;
    }

    public void setCode(String code) {
        this.code1 = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
