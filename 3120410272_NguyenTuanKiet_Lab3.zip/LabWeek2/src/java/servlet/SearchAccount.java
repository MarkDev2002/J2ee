package servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class SearchAccount extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>SearchAccount</title></head>");
        out.println("<body><h1>Ket qua tra dien thoai theo yeu cau cua ban :</h1>");
        out.println("<table border=1 cellPadding=1 cellSpacing=1>");
        String tentbao = request.getParameter("txtThuebao");
        // xay dung lenh SQL
        String newSQL = "SELECT * FROM CUSTOMER";
        if (tentbao != null && tentbao.length() != 0) {
            newSQL = newSQL + " where TenThueBao like '" + tentbao + "'";
        }
        String conStr = "jdbc:mysql://localhost:3306/QLDienThoai";
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection con = null;
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(conStr, "root", "");
            stmt = (Statement) con.createStatement();
            rs = ((java.sql.Statement) stmt).executeQuery(newSQL);
            out.println("<tr><th>So thu tu</th><th>Ten thue bao</th><th>So dien thoai</th > <th> Dia chi< / th > < / tr >\n");
            if (rs != null) {
                for (int i = 1; rs.next();) {
                    out.println("<tr>" + "<td>" + i + "</td>"
                            + "<td>" + rs.getString(2) + "</td>"
                            + "<td>" + rs.getString(3) + "</td>"
                            + "<td>" + rs.getString(4) + "</td> </tr>\n");
                }
            }
            rs.close();
            out.println("</table>");
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error: " + e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

}
