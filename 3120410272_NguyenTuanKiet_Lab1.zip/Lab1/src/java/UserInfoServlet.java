
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UserInfoServlet")
public class UserInfoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        // Lấy dữ liệu từ form
        String username = req.getParameter("username");
        String userEmail = req.getParameter("userEmail");

        // Hiển thị thông tin
        res.getWriter().println("<p>Username: " + username + "</p>");
        res.getWriter().println("<p>Email: " + userEmail + "</p>");
        res.getWriter().println("</body></html>");
    }
}
