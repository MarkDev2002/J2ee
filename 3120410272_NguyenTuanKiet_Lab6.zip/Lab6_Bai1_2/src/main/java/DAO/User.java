/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Models.Users;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author kinhc
 */
public class User {

    public static void main(String[] args) {
        //create();
        //updated();
        //delete();
        //findAll();
        //findByRole(true);
        //findByKeyword("Nguyễn");
        //findOne("TeoNV", "123456");
        //findPage(3, 5);
    }

    public static void create() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();

            Users entity = new Users();
            entity.setId("kiet123456");
            entity.setPassword("alo123456");
            entity.setFullname("NguyenTuanKiet");
            entity.setEmail("abc@gmail.com");
            entity.setAdmin(false);

            em.persist(entity);
            em.getTransaction().commit();
            System.out.println("Add New Success");

        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Error!! Add New !!");
        }
    }

    public static void update() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();

            Users entity = em.find(Users.class, "abcdefghjkl");
            entity.setPassword("aloabcdxyz");
            entity.setFullname("NguyenTuanKiet12345");
            entity.setEmail("abcde@gmail.com");
            entity.setAdmin(true);

            em.merge(entity);
            em.getTransaction().commit();
            System.out.println("Update Success");

        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Error!! Update !!");
        }
    }

    private static void delete() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();

            Users entity;
            entity = em.find(Users.class, "abcd");
            em.remove(entity);
            em.getTransaction().commit();
            System.out.println("Delete Success");

        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Error!! Delete !!");
        }
    }

    private static void findAll() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            String jpql = "SELECT o FROM Users o";
            TypedQuery<Users> query = em.createQuery(jpql, Users.class);
            List<Users> list = query.getResultList();

            for (Users user : list) {
                System.out.println("Id : " + user.getId());
                System.out.println("FullName : " + user.getFullname());
                System.out.println("Password : " + user.getPassword());
                System.out.println("Email : " + user.getEmail());
                System.out.println("Role : " + user.getAdmin());
            }

            System.out.println("Query Success");
        } catch (Exception e) {
            System.out.println("Error!!! Query findAll");
        }
    }

    private static void findByRole(boolean role) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            String jpql = "SELECT o FROM User o WHERE o.admin=:rolewhat";
            TypedQuery<Users> query = em.createQuery(jpql, Users.class);
            query.setParameter("rolewhat", role);
            List<Users> list = query.getResultList();

            for (Users user : list) {
                System.out.println("Id : " + user.getId());
                System.out.println("FullName : " + user.getFullname());
                System.out.println("Password : " + user.getPassword());
                System.out.println("Email : " + user.getEmail());
                System.out.println("Role : " + user.getAdmin());
            }

            System.out.println("Query Success");
        } catch (Exception e) {
            System.out.println("Error!!! Query findByRole");
        }
    }

    private static void findByKeyword(String keyword) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            String jpql = "SELECT o FROM User o WHERE o.fullname LIKE ?0";
            TypedQuery<Users> query = em.createQuery(jpql, Users.class);
            query.setParameter(0, keyword);
            List<Users> list = query.getResultList();

            for (Users user : list) {
                System.out.println("Id : " + user.getId());
                System.out.println("FullName : " + user.getFullname());
                System.out.println("Password : " + user.getPassword());
                System.out.println("Email : " + user.getEmail());
                System.out.println("Role : " + user.getAdmin());
            }

            System.out.println("Query Success");
        } catch (Exception e) {
            System.out.println("Error!!! Query findByKeyWord");
        }
    }

    private static void findOne(String username, String password) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            String jpql = "SELECT o FROM User o WHERE o.id=:id AND o.password=:pw";
            TypedQuery<Users> query = em.createQuery(jpql, Users.class);
            query.setParameter("id", username);
            query.setParameter("pw", password);
            Users user = query.getSingleResult();

            System.out.println("FullName : " + user.getFullname());
            System.out.println("Is Admin : " + user.getAdmin());

            System.out.println("Query Success");
        } catch (Exception e) {
            System.out.println("Error!!! Query findOne");
        }
    }

    private static void findPage(int page, int size) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab6_JPA");
        EntityManager em = emf.createEntityManager();
        try {
            String jpql = "SELECT o FROM User o";
            TypedQuery<Users> query = em.createQuery(jpql, Users.class);
            query.setFirstResult(page * size);
            query.setMaxResults(size);
            List<Users> list = query.getResultList();

            for (Users user : list) {
                System.out.println("Id : " + user.getId());
                System.out.println("FullName : " + user.getFullname());
                System.out.println("Password : " + user.getPassword());
                System.out.println("Email : " + user.getEmail());
                System.out.println("Role : " + user.getAdmin());
            }

            System.out.println("Query Success");
        } catch (Exception e) {
            System.out.println("Error!!! Query findPage");
        }
    }
}
