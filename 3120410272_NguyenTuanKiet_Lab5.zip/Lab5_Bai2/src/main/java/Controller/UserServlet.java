/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Model.User;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kinhc
 */
@WebServlet("/user")
public class UserServlet extends HttpServlet {

    List<User> listUser = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        listUser.add(new User("Username1", "Password1", true));
        listUser.add(new User("Username2", "Password2", false));
        listUser.add(new User("Username3", "Password3", true));

        req.setAttribute("message", "User management!");
        req.setAttribute("form", listUser.get(0));
        req.setAttribute("items", listUser);
        req.getRequestDispatcher("/views/user/index.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String user = req.getParameter("username");
        String password = req.getParameter("password");
        boolean remember = (req.getParameter("remember") != null);
        if (password.isBlank() || user.isBlank()){
            req.setAttribute("message", "Please enter all information!");
        }else{
            req.setAttribute("message", "User management! Add Success");
            listUser.add(new User(user, password, remember));

            if (listUser.get(listUser.size() - 1).isRemember()) {
                req.setAttribute("form", listUser.get(listUser.size() - 1));
            } else {
                req.setAttribute("form", null);
            }
        }
        req.setAttribute("items", listUser);
        
        req.getRequestDispatcher("/views/user/index.jsp").forward(req, res);
        
    }
}
