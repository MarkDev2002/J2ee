/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Model.Item;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kinhc
 */
@WebServlet({"/list", "/detailproduct"})
public class ListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String uri = req.getRequestURI();
        List<Item> listItem = Arrays.asList(new Item[]{
            new Item("Nokia 2020", "nokia.png", 500, 0.1),
            new Item("Samsung Xyz", "samsung.png", 700, 0.15),
            new Item("iPhone Xy", "iphone.png", 900, 0.25),
            new Item("Sony Erricson", "sony.png", 55, 0.3),
            new Item("Seamen", "seamen.png", 70, 0.5),
            new Item("Oppo 2021", "oppo.png", 200, 0.2)
        });
        if (uri.contains("list")) {
            req.setAttribute("listItem", listItem);
            req.getRequestDispatcher("/views/list/list.jsp").forward(req, res);
        } else if (uri.contains("detailproduct")) {
            int idProduct = Integer.parseInt(req.getParameter("idProduct"));
            req.setAttribute("item", listItem.get(idProduct));
            req.getRequestDispatcher("/views/list/detailproduct.jsp").forward(req, res);
        }
    }

}
